package herencia;

public class exposicionClaseheredada extends exposicionClaseMadre {
    public exposicionClaseheredada(int num1,int num2,int respuesta,Double potencia,double raiz2,double raiz3,int factorial,double respuesta2,double num3){
        super(num1,num2,respuesta,potencia,raiz2,raiz3,factorial,respuesta2,num3);
    }
    public static int multiplicar(int num1,int num2){
        int respuesta=num1*num2;
        return respuesta;
    }
    public static double potenciar(double num3,double potencia){
        double respuesta2=Math.pow(num3, potencia);
        return respuesta2;
    }
    public static double sacarRaiz2(double num3){
        double respuesta2=Math.sqrt(num3);
        return respuesta2;
    }
    public static double sacarRaiz3(double num3){
        double respuesta2=Math.cbrt(num3);
        return respuesta2;

    }
    public static int factoriales(int factorial){
        int respuesta=1;
        for (int i = 0; i < factorial; i++) {
            respuesta=respuesta*(i+1);
        }
        return respuesta;
    }
    
}
