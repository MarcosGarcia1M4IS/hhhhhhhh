package herencia;

import java.util.Scanner;

public class ExposicionMain {
    public static void main(String[] args) {
        Scanner a=new Scanner(System.in);
        int num1=1,num2=1,respuesta=1,factorial=1,op;
        double potencia=1,raiz2=1,raiz3=1,respuesta2=1,num3=1;
        boolean b=true;
        exposicionClaseheredada obj = new exposicionClaseheredada(num1, num2, respuesta, potencia, raiz2, raiz3, factorial, respuesta2, num3);
        while (b==true) {
        System.out.println("#_-MENU-_#");
        System.out.println("1-Multiplicacion");
        System.out.println("2-Potencia");
        System.out.println("3-Raiz cuadrada");
        System.out.println("4-Raiz cubica");
        System.out.println("5-Factorial");
        System.out.println("6-salir");
        op=a.nextInt();
        switch (op) {
            case 1:
                  System.out.println("Ingrese el primer numero");
                  num1=a.nextInt();
                  System.out.println("Ingrese el segundo numero");
                  num2=a.nextInt();
                 System.out.println("resultado: "+obj.multiplicar(num1, num2));
                break;
            case 2:
                 System.out.println("Ingrese el numero a elevar");
                 num3=a.nextInt();
                 System.out.println("Ingrese la potencia");
                 potencia=a.nextInt();
                 System.out.println("resutado: "+obj.potenciar(num3,potencia));

                break;
            case 3:
                 System.out.println("Ingrese el numero a sacar raiz cuadrada");
                 num3=a.nextInt();
                 System.out.println("resultado: "+obj.sacarRaiz2(num3));

                break;
            case 4:
                  System.out.println("Ingrese el numero a sacar raiz cubica");
                  num3=a.nextInt();
                  System.out.println("Respuesta: "+obj.sacarRaiz2(num3));


                break;
            case 5:
                  System.out.println("Ingrese un numero");
                  factorial=a.nextInt();
                  System.out.println("Respuesta: "+ obj.factoriales(factorial));
                break;
            case 6:
                 System.out.println("Adios...");
                 b=false;
                break;    
            default:
                break;
            }
        }
    }
}
