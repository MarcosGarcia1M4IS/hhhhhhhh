package herencia;

public class exposicionClaseMadre {
    protected int num1;
    protected int num2;
    protected int respuesta;
    protected double potencia;
    protected double raiz2;
    protected double raiz3;
    protected int factorial;
    protected double respuesta2;
    public exposicionClaseMadre(int num1,int num2,int respuesta,Double potencia,double raiz2,double raiz3,int factorial,double respuesta2,double num3){
        this.num1=num1;
        this.num2=num2;
        this.respuesta=respuesta;
        this.potencia=potencia;
        this.raiz2=raiz2;
        this.raiz3=raiz3;
        this.factorial=factorial;
        this.respuesta2=respuesta2;
    }
    public void setNum3(double num3) {
        this.num3 = num3;
    }
    public double getNum3() {
        return num3;
    }
    double num3;
    public int getNum1() {
        return num1;
    }
    public void setNum1(int num1) {
        this.num1 = num1;
    }
    public int getNum2() {
        return num2;
    }
    public void setNum2(int num2) {
        this.num2 = num2;
    }
    public double getPotencia() {
        return potencia;
    }
    public void setPotencia(double potencia) {
        this.potencia = potencia;
    }
    public void setFactorial(int factorial) {
        this.factorial = factorial;
    }
    public int getFactorial() {
        return factorial;
    }
    public void setRaiz2(double raiz2) {
        this.raiz2 = raiz2;
    }
    public double getRaiz2() {
        return raiz2;
    }
    public void setRaiz3(double raiz3) {
        this.raiz3 = raiz3;
    }
    public double getRaiz3() {
        return raiz3;
    }
    public void setRespuesta(int respuesta) {
        this.respuesta = respuesta;
    }
    public int getRespuesta() {
        return respuesta;
    }
    public void setRespuesta2(double respuesta2) {
        this.respuesta2 = respuesta2;
    }
    public double getRespuesta2() {
        return respuesta2;
    }
    
}
