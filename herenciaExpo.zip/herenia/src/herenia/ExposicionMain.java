package herenia;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class ExposicionMain {
    public static void main(String[] args) {
        Scanner a=new Scanner(System.in);
        int num1=1,num2=1,respuesta=1,factorial=1,op;
        double potencia=1,raiz2=1,raiz3=1,respuesta2=1,num3=1;
        boolean b=true;
        String num1s,num2s,num3s,potencias,factorials,ops;
        exposicionClaseheredada obj = new exposicionClaseheredada(num1, num2, respuesta, potencia, raiz2, raiz3, factorial, respuesta2, num3);
        while (b==true) {
            ops=JOptionPane.showInputDialog(null, "#_-MENU-_#"+"\n1-Multiplicar"+"\n2-Potencia"+"\n3-Raiz cuadrada"+"\n4-Raiz cubica"+"\n5-Factorial"+"\n6-salir");
            op=Integer.parseInt(ops);
        switch (op) {
            case 1:
                  num1s=JOptionPane.showInputDialog(null, "Ingrese el primer numero");
                  num2s=JOptionPane.showInputDialog(null, "Ingrese el segundo numero");
                  num1=Integer.parseInt(num1s);
                  num2=Integer.parseInt(num2s);
                 JOptionPane.showMessageDialog(null,"resultado: "+obj.multiplicar(num1, num2));
                break;
            case 2:
                 num3s=JOptionPane.showInputDialog(null, "Ingrese el numero a elevar");
                 num3=Integer.parseInt(num3s);
                 potencias=JOptionPane.showInputDialog(null, "Ingrese la potencia");
                 potencia=Integer.parseInt(potencias);
                 JOptionPane.showMessageDialog(null, "resutado: "+obj.potenciar(num3,potencia));

                break;
            case 3:
                 num3s=JOptionPane.showInputDialog(null, "Ingrese el numero a sacar raiz cuadrada");
                 num3=Integer.parseInt(num3s);
                 JOptionPane.showMessageDialog(null, "resultado: "+obj.sacarRaiz2(num3));

                break;
            case 4:
                  num3s=JOptionPane.showInputDialog(null, "Ingrese el numero a sacar raiz cubica");
                  num3=Integer.parseInt(num3s);
                  JOptionPane.showMessageDialog(null,"Respuesta: "+obj.sacarRaiz2(num3));


                break;
            case 5:
                  factorials=JOptionPane.showInputDialog(null, "Ingrese un numero");
                  factorial=Integer.parseInt(factorials);
                  JOptionPane.showMessageDialog(null,"Respuesta: "+ obj.factoriales(factorial));
                break;
            case 6:
                  JOptionPane.showMessageDialog(null,"Adios....");
                   b=false;
                break;    
            default:
                break;
            }
        }
    }
}
