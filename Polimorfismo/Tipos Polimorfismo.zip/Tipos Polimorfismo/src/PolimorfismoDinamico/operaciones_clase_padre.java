package PolimorfismoDinamico;
import java.util.Scanner;
import javax.swing.JOptionPane;

public abstract class operaciones_clase_padre {
	//un calculadora con polimorfismo
		protected int num1,num2,respuesta;
		
		public void pedirvalores() {
		num1=Integer.parseInt(JOptionPane.showInputDialog(null, "introduce un valor "));
		num2=Integer.parseInt(JOptionPane.showInputDialog(null, "segundo valor"));
		
		}
		public abstract void operaciones();{
		
		}
	public void MostrarResultado() {
	JOptionPane.showMessageDialog(null, "el resutado es "+respuesta);


	}


	}