package PolimorfismoDinamico;

public class division extends operaciones_clase_padre{
	@Override
	public void operaciones() {
	respuesta=num1/num2;

}
}
