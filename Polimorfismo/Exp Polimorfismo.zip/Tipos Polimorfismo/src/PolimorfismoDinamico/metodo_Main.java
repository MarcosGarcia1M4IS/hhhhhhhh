package PolimorfismoDinamico;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class metodo_Main {
	
	public static void main(String[] args) {
		
		try {
		JOptionPane.showMessageDialog(null, "SUMA");
		operaciones_clase_padre mensajero_suma= new suma();
mensajero_suma.pedirvalores();
mensajero_suma.operaciones();	
mensajero_suma.MostrarResultado();
	
JOptionPane.showMessageDialog(null, "resta");
	operaciones_clase_padre mensajero_resta= new resta();
	mensajero_resta.pedirvalores();
	mensajero_resta.operaciones();
	mensajero_resta.MostrarResultado();
	
	JOptionPane.showMessageDialog(null, "multplicacion");
	operaciones_clase_padre mensajero_mult = new multiplicacion();
	mensajero_mult.pedirvalores();
	mensajero_mult.operaciones();
	mensajero_mult.MostrarResultado();
	JOptionPane.showMessageDialog(null, "division");
	operaciones_clase_padre mensajero_divi = new division();
mensajero_divi.pedirvalores();	
mensajero_divi.operaciones();	
mensajero_divi.MostrarResultado();


		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, "dato no valido amigo",
				      "pruebe de nuevo!", JOptionPane.ERROR_MESSAGE);
		}
	}

}
