package PolimorfismoDinamico;

public class division extends operaciones_clase_padre{
	@Override
	public void operaciones() {
	int r;
	r=num1/num2;
		Math.round(r);
	respuesta=r;
		

}
}
