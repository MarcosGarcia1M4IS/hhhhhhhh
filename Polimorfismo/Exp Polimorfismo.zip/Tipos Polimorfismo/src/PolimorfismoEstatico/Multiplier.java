package PolimorfismoEstatico;

public class Multiplier {
	
	static void Multiply(int a, int b)

	{

	System.out.println("Multiplicación de enteros, Resultado = "+ a*b);

	}

	// Método 1

	static void Multiply(double a, double b)

	{

	System.out.println("Multiplicación de decimales, Resultado = "+ a*b);

	}

	// Método 2

	static void Multiply(double a, double b, double c)

	{

	System.out.println("Tres parámetros, Multiplicación de decimales, Resultado = "+ a*b*c);

	}

	public static void main(String[] args) {

	// usando el primer método

	Multiplier.Multiply(3,5);

	// usando el segundo método

	Multiplier.Multiply(3.5,5.1);

	// usando el tercer método 
	
	Multiplier.Multiply(3.6,5.2, 6.3);

	}

}
